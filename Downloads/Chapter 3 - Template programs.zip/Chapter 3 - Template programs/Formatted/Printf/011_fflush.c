#if 0
#include <stdio.h>

int main()
{
		printf("Hello World\n");

		printf("Hello\rWorld\n");

		printf("Hello\tWorld\n");

		printf("Hello\bWorld\n");

		printf("Hello\vWorld\n");

		printf("Hello World\f");

		printf("Hello\eWorld\n");

		printf("A\\B\\C\n");

		printf("\"Hello World\"\n");

		return 0;
}
#endif
#if 0
#include <stdio.h>

int main()
{

		printf("Hello emertxe\rWorld\n");
		return 0;
}
#endif
#if 1
#include <stdio.h>

int main()
{
		printf("Hello emertxe\rWorld");
		fflush(stdout);
		while (1);
		return 0;
}
#endif















