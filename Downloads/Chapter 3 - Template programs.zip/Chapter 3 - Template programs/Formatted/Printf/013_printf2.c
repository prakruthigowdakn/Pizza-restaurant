#if 1
#include <stdio.h>

int main()
{
	int ret;
	char string[] = { "Hello World" };

	ret = printf("%s\n", string);

	printf("The previous printf() printed %d chars\n", ret);

	return 0;
}
#endif
#if 0
#include <stdio.h>

int main()
{
	int ret;
	char string[] = "Hello World";

	ret = printf("%s", string);

	printf("The previous printf() printed %d chars\n", ret);

	return 0;
}
#endif
#if 0
#include <stdio.h>

int main()
{

	printf("%d\n", printf("vikas\n"));

	return 0;
}
#endif

#if 0
#include <stdio.h>

int main()
{
		if ( )
		{
				printf("Hello\n");
		}
		else
		{
				printf("World\n");
		}
		return 0;
}
#endif














