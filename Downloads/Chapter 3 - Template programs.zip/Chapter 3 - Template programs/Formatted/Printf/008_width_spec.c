 #include <stdio.h>

int main()
{
	printf("%3d %3d\n", 1, 1);
	printf("%3d %3d\n", 10, 10);
	printf("%3d %3d\n", 100, 100);
	printf("%3d %3d\n", 1000, 1000);

	printf("%10s\n", "Hello");
	printf("%20s\n", "Hello");

	printf("%*d\n", 1, 1);
	printf("%*d\n", 2, 1);
	printf("%*d\n", 3, 1);

	return 0;
}
