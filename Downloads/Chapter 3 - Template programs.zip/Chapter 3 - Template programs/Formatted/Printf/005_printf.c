#if 0
#include <stdio.h>

int main()
{
	char a[8] = "Emertxe";
	printf(a);
	return 0;
}

#endif
#if 0
#include <stdio.h>

int main()
{
	printf("Emertxe");
	return 0;
}

#endif
#if 1
#include <stdio.h>

int main()
{
	printf("Vikas Emertxe" + 3);
	return 0;
}

#endif















