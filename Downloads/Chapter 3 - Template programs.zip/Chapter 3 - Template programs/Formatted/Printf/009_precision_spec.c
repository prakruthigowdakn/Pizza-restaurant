#include <stdio.h>

int main()
{
	printf("%3.1d\n", 1);
	printf("%3.2d\n", 1);
	printf("%3.3d\n", 1);

	printf("%0.3f\n", 1.0);
	printf("%0.10f\n", 1.0);
	
	printf("%12.8s\n", "Hello World");

	return 0;
}
